<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "libreria";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT id_Autor, nombre, apellido, fecha_nacimiento FROM autores";
$result = $conn->query($sql);


if ($result->num_rows == 0) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Autores</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-6">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-4xl mx-auto">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Lista de Autores</h2>
        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr>
                    <th class="py-2 px-4 border-b">ID</th>
                    <th class="py-2 px-4 border-b">Nombre</th>
                    <th class="py-2 px-4 border-b">Apellido</th>
                    <th class="py-2 px-4 border-b">Fecha de Nacimiento</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Salida de datos de cada fila
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["id_Autor"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["nombre"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["apellido"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["fecha_nacimiento"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>";
                        echo "<a href='editar_autor.php?id=" . $row["id_Autor"] . "' class='text-blue-500 hover:underline'>Editar</a>";
                        echo "<a href='eliminar_autor.php?id=" . $row["id_Autor"] . "' class='text-blue-500 hover:underline'>Eliminar</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='py-2 px-4 border-b text-center'>No se encontraron autores</td></tr>";
                }

                // Cerrar conexión
                $conn->close();
                ?>
            </tbody>
        </table>
        <div class="mt-6">
            <a href="index.php" class="text-blue-500 hover:underline">Volver a la página principal</a>
        </div>
    </div>
</body>
</html>