<?php

function connection(){
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "libreria";

    // Conexión a la base de datos
    $connect = new mysqli($host, $username, $password, $database);

    // Verificar conexión
    if ($connect->connect_error) {
        die("Error de conexión: " . $connect->connect_error);
    }

    return $connect;
}

?>