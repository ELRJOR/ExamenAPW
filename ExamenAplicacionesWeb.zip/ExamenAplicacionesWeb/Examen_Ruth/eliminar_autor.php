<?php
// Verificar si se proporcionó el parámetro ID en la URL
if (isset($_GET['id'])) {
    // Conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "libreria";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // ID del autor a eliminar
    $idAutor = $_GET['id'];

    // Consulta SQL para eliminar el autor
    $sqlDelete = "DELETE FROM Autor WHERE ID_Autor = $idAutor";

    if ($conn->query($sqlDelete) === TRUE) {
        echo "<script>alert('Nuevo autor añadido exitosamente'); window.location.href='ver_autores.php.php';</script>";
    } else {
        echo "Error al eliminar el autor: " . $conn->error;
    }

    // Cerrar conexión
    $conn->close();
} else {
    echo "No se especificó ningún autor para eliminar.";
}
?>
