<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "libreria";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables para almacenar datos del libro
$idLibro = "";
$titulo = "";
$fechaPublicacion = "";
$precio = "";
$idAutor = "";

// Verificar si se proporcionó el parámetro ID en la URL
if (isset($_GET['id'])) {
    $idLibro = $_GET['id'];

    // Consulta SQL para obtener los datos del libro específico
    $sql = "SELECT id_libro, titulo, fecha_publicacion, precio, id_autor FROM libros WHERE id_libro = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idLibro);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Obtener los datos del libro
        $row = $result->fetch_assoc();
        $titulo = $row['titulo'];
        $fechaPublicacion = $row['fecha_publicacion'];
        $precio = $row['precio'];
        $idAutor = $row['id_autor'];
    } else {
        echo "No se encontró ningún libro con ID: $idLibro";
        exit();
    }
    $stmt->close();
}

// Procesamiento del formulario cuando se envía
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $idLibro = $_POST['idLibro'];
    $titulo = $_POST['titulo'];
    $fechaPublicacion = $_POST['fecha_publicacion'];
    $precio = $_POST['precio'];
    $idAutor = $_POST['id_autor'];

    // Actualizar los datos del libro en la base de datos
    $sqlUpdate = "UPDATE libros SET titulo = ?, fecha_publicacion = ?, precio = ?, id_autor = ? WHERE id_libro = ?";
    $stmt = $conn->prepare($sqlUpdate);
    $stmt->bind_param("ssdii", $titulo, $fechaPublicacion, $precio, $idAutor, $idLibro);

    if ($stmt->execute() === TRUE) {
        echo "Los datos del libro han sido actualizados correctamente.";
    } else {
        echo "Error al actualizar los datos del libro: " . $stmt->error;
    }
    $stmt->close();
}

// Cerrar conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Libro</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-6">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md mx-auto">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Editar Libro</h2>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="hidden" name="idLibro" value="<?php echo $idLibro; ?>">
            <div class="mb-4">
                <label for="titulo" class="block text-gray-800 font-bold mb-2">Título:</label>
                <input type="text" id="titulo" name="titulo" value="<?php echo $titulo; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="fecha_publicacion" class="block text-gray-800 font-bold mb-2">Fecha de Publicación:</label>
                <input type="date" id="fecha_publicacion" name="fecha_publicacion" value="<?php echo $fechaPublicacion; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="precio" class="block text-gray-800 font-bold mb-2">Precio:</label>
                <input type="text" id="precio" name="precio" value="<?php echo $precio; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="id_autor" class="block text-gray-800 font-bold mb-2">ID del Autor:</label>
                <input type="text" id="id_autor" name="id_autor" value="<?php echo $idAutor; ?>" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mt-6">
                <button type="submit" class="bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700">Guardar Cambios</button>
                <a href="ver_libros.php" class="ml-4 text-gray-600 hover:text-gray-800">Cancelar o atrás</a>
            </div>
        </form>
    </div>
</body>
</html>
