<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "libreria";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL para obtener libros con detalles de autor
$sql = "SELECT libros.id_libro, libros.titulo, libros.fecha_publicacion, libros.precio, autores.nombre AS autor
        FROM libros
        INNER JOIN autores ON libros.id_autor = autores.id_autor";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Libros</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-6">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-4xl mx-auto">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Lista de Libros</h2>
        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr>
                    <th class="py-2 px-4 border-b">ID</th>
                    <th class="py-2 px-4 border-b">Título</th>
                    <th class="py-2 px-4 border-b">Fecha de Publicación</th>
                    <th class="py-2 px-4 border-b">Autor</th>
                    <th class="py-2 px-4 border-b">Precio</th>
                    <th class="py-2 px-4 border-b">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Salida de datos de cada libro
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["id_libro"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["titulo"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["fecha_publicacion"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["autor"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>" . $row["precio"]. "</td>";
                        echo "<td class='py-2 px-4 border-b'>";
                        echo "<a href='editar_libro.php?id=" . $row["id_libro"] . "' class='text-blue-500 hover:underline'>Editar</a> | ";
                        echo "<a href='eliminar_libro.php?id=" . $row["id_libro"] . "' class='text-red-500 hover:underline' onclick=\"return confirm('¿Estás seguro de eliminar este libro?');\">Eliminar</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='py-2 px-4 border-b text-center'>No se encontraron libros</td></tr>";
                }

                // Cerrar conexión
                $conn->close();
                ?>
            </tbody>
        </table>
        <div class="mt-6">
            <a href="index.php" class="text-blue-500 hover:underline">Volver a la página principal</a>
        </div>
    </div>
</body>
</html>
