<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "libreria";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Manejar el envío del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Titulo = $_POST['titulo'];
    $FechaPublicacion = $_POST['fecha_publicacion'];
    $Precio = $_POST['precio'];
    $Id_autor = $_POST['id_autor'];

    // Insertar datos en la tabla libros
    $sql = "INSERT INTO libros (titulo, fecha_publicacion, precio, id_autor) VALUES (?, ?, ?, ?)";

    // Preparar la declaración
    $stmt = $conn->prepare($sql);

    // Verificar si la preparación de la declaración fue exitosa
    if ($stmt === false) {
        die('Error al preparar la consulta: ' . $conn->error);
    }

    // Vincular parámetros y tipos
    $stmt->bind_param("sssi", $Titulo, $FechaPublicacion, $Precio, $Id_autor);

    // Ejecutar la declaración y manejar errores
    if ($stmt->execute() === TRUE) {
        echo "<script>alert('Nuevo libro añadido exitosamente'); window.location.href='index.php';</script>";
    } else {
        echo "Error al añadir el libro: " . $stmt->error;
    }

    // Cerrar la declaración
    $stmt->close();
}

// Cerrar la conexión
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Libro</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-6">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md mx-auto">
        <h2 class="text-2xl font-bold mb-6 text-gray-800">Añadir nuevo libro</h2>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="mb-4">
                <label for="titulo" class="block text-gray-800 font-bold mb-2">Título:</label>
                <input type="text" id="titulo" name="titulo" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="fecha_publicacion" class="block text-gray-800 font-bold mb-2">Fecha de Publicación:</label>
                <input type="date" id="fecha_publicacion" name="fecha_publicacion" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="id_autor" class="block text-gray-800 font-bold mb-2">ID del Autor:</label>
                <input type="number" id="id_autor" name="id_autor" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mb-4">
                <label for="precio" class="block text-gray-800 font-bold mb-2">Precio:</label>
                <input type="text" id="precio" name="precio" class="w-full px-3 py-2 leading-tight border rounded shadow appearance-none focus:outline-none focus:shadow-outline">
            </div>
            <div class="mt-6">
                <button type="submit" class="bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700">Agregar Libro</button>
                <a href="index.php" class="ml-4 text-gray-600 hover:text-gray-800">Cancelar</a>
            </div>
        </form>
    </div>
</body>
</html>
