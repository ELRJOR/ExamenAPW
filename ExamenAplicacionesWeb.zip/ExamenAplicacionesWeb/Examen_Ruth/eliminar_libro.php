<?php
// Verificar si se recibió un parámetro 'id_libro' a través de GET
if (isset($_GET['id_libro']) && !empty($_GET['id_libro'])) {
    // Obtener el id del libro a eliminar
    $id_libro = $_GET['id_libro'];

    // Conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "libreria";

    // Crear la conexión
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Consulta SQL para eliminar el libro
    $sql = "DELETE FROM libros WHERE id_libro = ?";

    // Preparar la declaración
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_libro);

    // Ejecutar la declaración
    if ($stmt->execute()) {
        // Redireccionar a la página principal o a una página de confirmación
        header("Location: ver_libros.php");
        exit();
    } else {
        echo "Error al intentar eliminar el libro: " . $conn->error;
    }

    // Cerrar la declaración y la conexión
    $stmt->close();
    $conn->close();
} else {
    // Si no se proporcionó un id_libro válido, redirigir a la página principal
    header("Location: ver_libros.php");
    exit();
}
?>
